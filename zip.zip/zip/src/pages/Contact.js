const Contact = () => {
    return <h1>Contact Me</h1>;
  };
  
  export default Contact;
const Home = () => {
    return (
        <>
            
      <div class="p-5 text-center">
        <h1>My Gallery</h1> 
      </div>
      <div className="container w-75">
      
        <div className="row d-flex justify-content-center">
          <div className="col-sm-4 my-3">
            <div className="card" >
              <img className="card-img-top" src="https://picsum.photos/id/23/300/300" alt="Card image"/>
              <div className="card-body">
                <h4 className="card-title">John Doe</h4>
                <p className="card-text">Some example text.</p>
                <a href="#" className="btn btn-primary">See Profile</a>
              </div>
            </div>
          </div>
          <div className="col-sm-4 my-3">
            <div className="card" >
              <img className="card-img-top" src="https://picsum.photos/id/30/300/300" alt="Card image"/>
              <div className="card-body">
                <h4 className="card-title">John Doe</h4>
                <p className="card-text">Some example text.</p>
                <a href="#" className="btn btn-primary">See Profile</a>
              </div>
            </div>
          </div>
          <div className="col-sm-4 my-3">
            <div className="card" >
              <img className="card-img-top" src="https://picsum.photos/id/42/300/300" alt="Card image"/>
              <div className="card-body">
                <h4 className="card-title">John Doe</h4>
                <p className="card-text">Some example text.</p>
                <a href="#" className="btn btn-primary">See Profile</a>
              </div>
            </div>
          </div>
          <div className="col-sm-4 my-3">
            <div className="card" >
              <img className="card-img-top" src="https://picsum.photos/id/63/300/300" alt="Card image"/>
              <div className="card-body">
                <h4 className="card-title">John Doe</h4>
                <p className="card-text">Some example text.</p>
                <a href="#" className="btn btn-primary">See Profile</a>
              </div>
            </div>
          </div>
        </div>
      </div>
        </>
    );
  };
  
  export default Home;
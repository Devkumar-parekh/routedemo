const Blogs = () => {
    return (
        <>
      <div class="p-5 text-center">
        <h1>About Us</h1> 
      </div>
      <div className="container w-75">
        <div className="row d-flex justify-content-center">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent quis consectetur augue. Praesent nibh urna, congue ac egestas tempor, pulvinar eu elit. Etiam sem lectus, commodo at volutpat id, luctus at ex. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Vivamus aliquam, eros eget iaculis rhoncus, tellus diam commodo quam, eget condimentum elit sem in diam. Ut dictum tincidunt ipsum quis posuere. Curabitur maximus egestas rhoncus.

Nulla molestie convallis tellus eget ultricies. Suspendisse potenti. Proin posuere tellus in eros imperdiet vestibulum. Suspendisse sit amet augue a velit ornare lobortis vel at tellus. Sed mattis feugiat urna, in tincidunt orci euismod quis. In at iaculis lectus. Integer ex quam, accumsan id metus ut, porttitor pretium neque. Etiam convallis molestie massa sit amet venenatis. Cras nibh felis, fringilla quis congue non, iaculis posuere lacus. Mauris elit massa, pulvinar sit amet pellentesque eu, posuere eget tortor. Sed non arcu sed felis porttitor euismod. Mauris dapibus, elit luctus dignissim ornare, dolor leo malesuada massa, ac porta felis augue nec nisi. Nulla posuere ultricies mi, at rutrum nunc accumsan quis. Donec hendrerit, nulla ut fringilla sodales, leo mi laoreet quam, ut tempus tellus eros eget mi. Aliquam varius nunc nec porta eleifend.

Aliquam erat volutpat. Nam viverra pharetra ipsum, at auctor orci dignissim eu. Aenean aliquam a arcu in consequat. Integer neque sapien, commodo ut velit nec, iaculis iaculis massa. Cras pulvinar, mi eu ornare molestie, lorem augue eleifend purus, non sagittis felis mi sed ligula. Morbi interdum vestibulum dictum. Pellentesque quis purus scelerisque, elementum risus at, dignissim nisi. Etiam faucibus nulla id tortor fermentum, ac fermentum dui hendrerit. Suspendisse sodales turpis at arcu bibendum, eu ornare massa elementum. Sed malesuada felis quis leo gravida, sit amet dignissim elit commodo. Nunc ac vulputate enim, eu venenatis turpis. Phasellus blandit lectus elit, sit amet tristique ipsum lacinia in. Sed fermentum id neque quis pellentesque. Morbi non aliquam felis. Vivamus suscipit ante risus, non maximus lectus tristique sed. Phasellus commodo mollis nisi, quis rutrum justo dignissim pulvinar.

Aliquam sed efficitur orci. Nullam rutrum nec tortor et vehicula. Sed blandit commodo laoreet. Fusce auctor nibh non velit tincidunt, sit amet condimentum ante hendrerit. Fusce sagittis, risus vel iaculis lobortis, justo sem scelerisque nibh, sed rhoncus odio orci non leo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Suspendisse a tempor quam, ac cursus tortor.

Etiam in ligula nisi. Duis mattis nulla quis erat efficitur vehicula. Sed vitae fermentum mauris. Ut augue neque, aliquet quis ultrices id, blandit in leo. Aenean tellus velit, maximus rhoncus pulvinar nec, consectetur id justo. Mauris nec euismod tellus. Fusce elit risus, pretium quis eros eget, molestie tincidunt nisi. Praesent convallis tortor risus, at aliquet ex rhoncus at. In vel orci at felis semper fermentum. Integer bibendum quis nisi ac tincidunt. Aenean iaculis dolor iaculis sapien varius efficitur. Sed rhoncus neque auctor ligula suscipit pellentesque.
        </div>
      </div>
    </>
    );
  };
  
  export default Blogs;